# DataStax Bulk Loader

A unified tool for loading into and unloading from DSE storage engines (i.e., Cassandra/Apollo and DataStax Enterprise).

## Documentation

Read the [manual].

## Issue Management

DataStax Bulk Loader has its own [Jira project].

The original DSP ticket was [DSP-13637].

[manual]: manual/
[Jira project]: https://datastax.jira.com/projects/DAT/summary
[DSP-13637]: https://datastax.jira.com/browse/DSP-13637
