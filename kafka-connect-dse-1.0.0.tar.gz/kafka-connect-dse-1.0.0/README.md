DataStax Apache® Kafka® Connector

The DataStax Apache® Kafka® Connector enables users to ingest topics from Apache® Kafka® to tables in DataStax Enterprise. Visit the documentation for all connector information.

https://docs.datastax.com/en/kafka/doc