#!/bin/sh
cassandra-stress user profile=iot.yaml ops\(insert=1,query_by_machine_id=1\) duration=1m -rate threads=24 -mode native cql3 user=cassandra password=foobar123! -node 127.0.0.1 -log file=./50write50read_runx.log -graph file=./50write50read_runx.html title=50write50read_runx revision=50write50read_runx
