#!/bin/sh
cassandra-stress user n=1000000 profile=iot.yaml ops\(insert=9,query_by_machine_id=1\) -mode native cql3 user=cassandra password=foobar123! -node 127.0.0.1 -log file=./90write10read_gauge.log -graph file=./90write10read_gauge.html title=90write10read_gauge revision=90write10read_gauge
