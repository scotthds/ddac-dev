#!/bin/sh
cassandra-stress user n=1000000 profile=iot-base.yaml ops\(insert=1\) -rate threads=36 -mode native cql3 user=cassandra password=foobar123! -node 127.0.0.1 -log file=./base_dataset_write.log -graph file=./base_dataset_write.html title=base_dataset_write revision=base_dataset_write_0
